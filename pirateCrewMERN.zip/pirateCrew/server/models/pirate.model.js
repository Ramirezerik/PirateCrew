const mongoose = require("mongoose");

const PirateSchema = new mongoose.Schema( {
    // The keys in the object sent to axios.post as 2nd argument need to match up to what they are named here
    pirateName: {
        type: String,
        required: [true, "Pirate name is required"],
        minlength: [3, "Pirate name must be at least 3 characters long"],
    },
    crewPosition: {
        type: String,
        required: [true, "Crew position is required"],
        enum:["Capitan", "First Mate", "Quarter Master", "Boatswain", "Powder Monkey"]
    },
    imageURL: {
        type: String,
        required: [true, "Pirate image URL is required"],
    },
    treasureChests: {
        type: String,
        required: [true, "# of tresure chests are required"],
        enum:["0","1", "2", "3"]
    },

    catchPhrase: {
        type: String,
        required: [true, "Pirate Catch Phrase is required"],
        minlength: [3, "Pirate Catch Phrase must be at least 3 charachters long"],
    },

    pegLeg: {
        type: Boolean,
        default: true,
        required: [true, " Does Pirate have a peg leg is required"],
    },

    eyePatch: {
        type: Boolean,
        default: true,
        required: [true, " Does Pirate have an eye patch is required"],
    },

    hookHand: {
        type: Boolean,
        default: true,
        required: [true, " Does Pirate have a hook hand is required"],
    },
},
    { timestamps: true }
);

const Pirate = mongoose.model("Pirate", PirateSchema);

module.exports = Pirate;

// 

