const Pirate = require("../models/pirate.model");

module.exports = {
  //creates a new Pirate
    createPirate: (request, response) => {
        Pirate.create(request.body)
            .then((newPirate) => {
                response.json(newPirate);
            })
            .catch((err) => {
                console.log(err);
                response.status(400).json(err);
            });
    },
  //finds a specific Pirate
    getOnePirate: (request, response) => {
        Pirate.findById({ _id: request.params.id })
        .then((onePirate) => {
        response.json(onePirate);
        })
        .catch((err) => {
            console.log(err);
            response.status(400).json(err);
        });
    },

  //finds all pirate menbers 
    getAllPirates: (request, response) => {
        Pirate.find({})
            .collation({ locale: "en", strength: 2 })
            .sort({ PirateName: 1 })
            .then((allPirates) => {
        response.json(allPirates);
        })
        .catch((err) => {
            console.log(err);
            response.status(400).json(err);
        });
    },

  //deletes 1a pirate
    deletePirate: (request, response) => {
        Pirate.deleteOne({ _id: request.params.id })
            .then((deletedPirate) => {
            console.log("deleted");
            response.json(deletedPirate);
            })
            .catch((err) => {
            console.log(err);
            response.status(400).json(err);
        });
    },

  //edit a pirate
    editPirate: (request, response) => {
        console.log(request.body);
        console.log(request.params);
        Pirate.findOneAndUpdate({ _id: request.params.id }, request.body, {
            new: true,
            runValidators: false, 
        })
            .then((updatedPirate) => {
            console.log("SUCCESS");
            console.log(updatedPirate);
            response.json(updatedPirate);
        })
            .catch((err) => {
                console.log("ERROR");
                console.log(err);
                response.status(400).json(err);
        });
    },
};

//

