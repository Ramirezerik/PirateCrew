import logo from './logo.svg';
import './App.css';
import {Router} from '@reach/router';
import NewPirate from './components/NewPirate';
import AllPirates from './components/AllPirates';
// import EditPirate from './components/EditPirate';
import PirateDetails from './components/DetailsPirate';


function App() {
  return (
    <div className="App">
      <Router>
        <AllPirates path="/"/>
        <NewPirate path="/new"/>
        {/* <EditPirate path="/edit/:id"/> */}
        <PirateDetails path="/details/:id"/>
      </Router>
    </div>
  );
}

export default App;

