import React, {useEffect, useState} from 'react';
import { Link, navigate } from '@reach/router';
import axios from 'axios';


const AllPirates = (props)=>{
    const {id} = props;
    const [pirates, setPirates] = useState({});
    // const [pirate, setPirate] = useState({})
    const [pirateList, setPirateList] = useState([]);

    useEffect(()=> {
        axios.get('http://localhost:8000/api/pirates')
        .then((response)=>{
            console.log(response);
            console.log(response.data);
            setPirateList(response.data);
        })
        .catch((err)=>{
            console.log(err)
        })
    }, [])

    const deleteHandler = (id, index) => {
        console.log("handle delete", id);
        axios
            .delete(`http://localhost:8000/api/pirates/${id}`)
            .then((response) => {
                console.log(response);
                const piratesCopy = [...pirates];
                const filteredArr = piratesCopy.filter(
                    (pirate, idx) => idx !== index
                );
                setPirates(filteredArr);
            })
            .catch((err)=> console.log(err));
    };


    return(
        <div>
            <div className="navBar">
                <h1>Add Pirate</h1>
                <Link to="/new" class="btn btn-primary">Add Pirate</Link>
            </div>
            <div className="body">
                <table >
                    <thead >
                        <tr>
                        </tr>
                    </thead>
                    <tbody className="profile">
                        {
                            pirateList?
                            pirateList.map((pirate, index)=>(
                                <tr key={index} className="profile">
                                    <td>
                                        <img className="table-image" src={pirate.imageURL}/>
                                    </td>
                                    <td>{pirate.pirateName}</td>
                                    {/* <button onClick={()=>{navigate(`/edit/${pirate._id}`)}} class="btn btn-link">Edit</button> */}
                                    <button onClick={()=>{navigate(`/details/${pirate._id}`)}} class="btn btn-info">View Pirate</button>
                                    <button type="button" id="right-form-btn" onClick={()=> deleteHandler(pirate._id, index)} class="btn btn-danger">Walk the Plank</button>
                                </tr>
                            ))
                            :null
                        }
                    </tbody>
                </table>
            </div>
        </div>
    )
}
export default AllPirates;



