import React, {useEffect, useState} from 'react';
import axios from 'axios';
import {Link} from "@reach/router"

const PirateDetails = (props) => {
    const {id} = props;
    const [pirates, setPirates] = useState({});
    const [pirate, setPirate] = useState({});


    useEffect(()=> {
        axios
            .get(`http://localhost:8000/api/pirates/${id}`)
            .then((response)=>{
                console.log(response);
                console.log(response.data);
                setPirates(response.data);
            })
            .catch((err)=> {
                console.log(err);
            })
    }, [id]);

    const deleteHandler = (id) => {
        axios
            .delete(`http://localhost:8000/api/pirates/${id}`)
            .then((response)=> {
                console.log(response);
                setPirate(pirate.filter((pirate)=> pirate._id !== id));
            })
            .catch((err)=> {
                console.log(err.response);
            });
    };

    return (
        <div>
            <div className="navBar">
                <h1>{pirates.pirateName}</h1>
                <Link to="/" class="btn btn-primary">Crew Board</Link>
            </div>
            <div className="body">
                
                <div className="pirate-Pic" >
                    <img className="pirate-image" src={pirates.imageURL} alt="Pirate Picture"/>
                <h1> 
                    "{pirates.catchPhrase}"
                </h1>
                </div>

                <div className="pirate-Bio" >
                    <h2>About</h2>
                    <h3>Position: {pirates.crewPosition}</h3>
                    <h3>Treasures: {pirates.treasureChests}</h3>
                    <h3>Peg Leg: {pirates.pegLeg ? <p>Yes</p> : <p>No</p>}</h3>
                    <h3>Eye Patch: {pirates.eyePatch ? <p>Yes</p> : <p>No</p>}</h3>
                    <h3>Hook Hand: {pirates.hookHand ? <p>Yes</p> : <p>No</p>}</h3>
                </div>

                {/* <button onClick={()=> deleteHandler(pirates._id)} class="btn btn-danger">
                    Delete Pirate
                </button> */}
            </div>
        </div>
    );
};

export default PirateDetails;

//
