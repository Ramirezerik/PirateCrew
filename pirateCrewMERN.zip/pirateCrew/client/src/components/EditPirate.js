// import React, {useEffect, useState} from 'react';
// import {Link, navigate} from '@reach/router';
// import axios from 'axios';
// import NewPirate from './NewPirate';


// const EditPirate = (props) => {
//     const {id} = props;
//     const [updateName,setUpdateName] = useState("");
//     const [updateType,setUpdateType] = useState("");
//     const [updateDescription,setUpdateDescription] = useState("");
//     const [updateSkill1,setUpdateSkill1] = useState("");
//     const [updateSkill2,setUpdateSkill2] = useState("");
//     const [updateSkill3,setUpdateSkill3] = useState("");

//     useEffect(()=> {
//         axios
//             .get(`http://localhost:8000/api/pirates/${id}`)
//             .then((response)=> {
//                 console.log(response.data);
//                 setUpdateName(response.data.name);
//                 setUpdateType(response.data.type);
//                 setUpdateDescription(response.data.description);
//                 setUpdateSkill1(response.data.skill1);
//                 setUpdateSkill2(response.data.skill2);
//                 setUpdateSkill3(response.data.skill3);
//             })
//             .catch((err)=> {
//                 console.log(err);
//                 navigate("/error");
//             })
//     }, [id]);

//     const onSubmitHandler = (e) => {
//         e.preventDefault();
//         axios 
//             .put(`http://localhost:8000/api/pirates/${id}`, {
//                 name: updateName,
//                 type: updateType,
//                 description: setUpdateDescription,
//                 skill1: setUpdateSkill1,
//                 skill2: setUpdateSkill2,
//                 skill3: setUpdateSkill3
//             })
//             .then((response)=> {
//                 console.log(response.data);
//                 navigate("/");
//             })
//             .catch((err)=> {
//                 console.log(err.response);
//             });
//     };

//     return(
//         <div>
//             {/* <Header link={"/"} linkText="back to home" subText="Edit Pirate" /> */}
//             <form onSubmit={onSubmitHandler}>
//                 <label>Name:</label>
//                 <input 
//                     type="text" 
//                     onChange={(e) => setUpdateName(e.target.value)} 
//                     value={updateName} 
//                 />
//                 <br />
//                 <label>Type:</label>
//                 <input 
//                     type="text" 
//                     onChange={(e) => setUpdateType(e.target.value)} 
//                     value={updateType} 
//                 />
//                 <br />
//                 <label>Description:</label>
//                 <input 
//                     type="text" 
//                     onChange={(e) => setUpdateDescription(e.target.value)} 
//                     value={updateDescription} 
//                 />
//                 <br />
//                 <p>Skills (optional): </p>
//                 <p>
//                     Skill 1:{" "}
//                     <input 
//                     type="text"
//                     onChange={(e) => setUpdateSkill1(e.target.value)}
//                     value={updateSkill1}
//                     />
//                 </p>
//                 <p>
//                     Skill 2:{" "}
//                     <input 
//                     type="text"
//                     onChange={(e) => setUpdateSkill2(e.target.value)}
//                     value={updateSkill2}
//                     />
//                 </p>
//                 <p>
//                     Skill 3:{" "}
//                     <input 
//                     type="text"
//                     onChange={(e) => setUpdateSkill3(e.target.value)}
//                     value={updateSkill3}
//                     />
//                 </p>
//                 <button class="btn btn-warning">
//                     Edit Pirate
//                 </button>
//             </form>
//         </div>
//     );
// };

// export default EditPirate;


